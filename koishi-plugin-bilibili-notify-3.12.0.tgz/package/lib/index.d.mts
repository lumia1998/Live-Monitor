import { DataService } from "@koishijs/plugin-console";
import { Context, Schema } from "koishi";

//#region src/config.d.ts
interface BilibiliNotifyConfig {
  require: {};
  key: string;
  subTitle: {};
  advancedSub: boolean;
  subs: Array<{
    name: string;
    uid: string;
    dynamic: boolean;
    dynamicAtAll: boolean;
    live: boolean;
    liveAtAll: boolean;
    liveGuardBuy: boolean;
    superchat: boolean;
    wordcloud: boolean;
    liveSummary: boolean;
    platform: string;
    target: string;
  }>;
  basicSettings: {};
  logLevel: number;
  userAgent: string;
  ai: {
    enable: boolean;
    apiKey?: string;
    baseURL?: string;
    model?: string;
    persona?: string;
  };
  master: {};
  dynamic: {};
  dynamicUrl: boolean;
  dynamicCron: string;
  dynamicVideoUrlToBV: boolean;
  pushImgsInDynamic: boolean;
  live: {};
  wordcloudStopWords: string;
  liveSummary: Array<string>;
  customGuardBuy: {
    enable: boolean;
    guardBuyMsg?: string;
    captainImgUrl?: string;
    supervisorImgUrl?: string;
    governorImgUrl?: string;
  };
  restartPush: boolean;
  pushTime: number;
  customLiveStart: string;
  customLive: string;
  customLiveEnd: string;
  followerDisplay: boolean;
  hideDesc: boolean;
  style: {};
  removeBorder: boolean;
  cardColorStart: string;
  cardColorEnd: string;
  cardBasePlateColor: string;
  cardBasePlateBorder: string;
  enableLargeFont: boolean;
  font: string;
  filter: {};
}
//#endregion
//#region src/type/auth.d.ts
declare enum BiliLoginStatus {
  NOT_LOGIN = 0,
  LOADING_LOGIN_INFO = 1,
  LOGIN_QR = 2,
  LOGGING_QR = 3,
  LOGGING_IN = 4,
  LOGGED_IN = 5,
  LOGIN_SUCCESS = 6,
  LOGIN_FAILED = 7
}
type BiliDataServer = {
  status: BiliLoginStatus;
  msg: string;
  data?: any;
};
//#endregion
//#region src/type/subscription.d.ts
type Channel = {
  channelId: string;
  dynamic: boolean;
  dynamicAtAll: boolean;
  live: boolean;
  liveAtAll: boolean;
  liveGuardBuy: boolean;
  superchat: boolean;
  wordcloud: boolean;
  liveSummary: boolean;
  spacialDanmaku: boolean;
  spacialUserEnterTheRoom: boolean;
};
type ChannelArr = Array<Channel>;
type TargetItem = {
  channelArr: ChannelArr;
  platform: string;
};
type Target = Array<TargetItem>;
type CustomCardStyle = {
  enable: boolean;
  cardColorStart?: string;
  cardColorEnd?: string;
  cardBasePlateColor?: string;
  cardBasePlateBorder?: string;
};
type CustomLiveMsg = {
  enable: boolean;
  customLiveStart?: string;
  customLive?: string;
  customLiveEnd?: string;
};
type CustomGuardBuy = {
  enable: boolean;
  guardBuyMsg?: string;
  captainImgUrl?: string;
  supervisorImgUrl?: string;
  governorImgUrl?: string;
};
type CustomLiveSummary = {
  enable: boolean;
  liveSummary?: Array<string> | string;
};
type CustomSpecialDanmakuUsers = {
  enable: boolean;
  specialDanmakuUsers?: Array<string>;
  msgTemplate?: string;
};
type CustomSpecialUsersEnterTheRoom = {
  enable: boolean;
  specialUsersEnterTheRoom?: Array<string>;
  msgTemplate?: string;
};
type Subscription = {
  uname: string;
  uid: string;
  roomid: string;
  dynamic: boolean;
  live: boolean;
  liveEnd: boolean;
  target: Target;
  customCardStyle: CustomCardStyle;
  customLiveMsg: CustomLiveMsg;
  customLiveSummary: CustomLiveSummary;
  customGuardBuy: CustomGuardBuy;
  customSpecialDanmakuUsers: CustomSpecialDanmakuUsers;
  customSpecialUsersEnterTheRoom: CustomSpecialUsersEnterTheRoom;
};
type Subscriptions = Record<string, Subscription>;
//#endregion
//#region src/data_server.d.ts
declare class BilibiliNotifyDataServer extends DataService<BiliDataServer> {
  private biliData;
  constructor(ctx: Context);
  get(): Promise<BiliDataServer>;
}
//#endregion
//#region src/index.d.ts
declare const inject: string[];
declare const name = "bilibili-notify";
declare const usage = "\n<h1>Bilibili-Notify</h1>\n<p>\u4F7F\u7528\u95EE\u9898\u8BF7\u52A0\u7FA4\u54A8\u8BE2 801338523</p>\n\n---\n\n\u4E3B\u4EBA\u597D\u5440\uFF5E\u6211\u662F\u7B28\u7B28\u5973\u4EC6\u5C0F\u52A9\u624B\u54D2 (\u3003\u2200\u3003)\u2661\n\u4E13\u95E8\u5E2E\u4E3B\u4EBA\u7BA1\u7406 B \u7AD9\u8BA2\u9605\u548C\u76F4\u64AD\u63A8\u9001\u7684\uFF01\n\u5973\u4EC6\u867D\u7136\u7B28\u7B28\u7684\uFF0C\u4F46\u662F\u4F1A\u5C3D\u529B\u4E0D\u51FA\u9519\u54E6\uFF5E\n\u4E3B\u4EBA\uFF0C\u53EA\u8981\u6309\u7167\u5973\u4EC6\u7684\u63D0\u793A\u4E00\u6B65\u4E00\u6B65\u8BBE\u7F6E\uFF0C\u5973\u4EC6\u5C31\u53EF\u4EE5\u4E56\u4E56\u5E2E\u60A8\u5DE5\u4F5C\u5566\uFF01\n\n\u9996\u5148\u5462\uFF5E\u8BF7\u4E3B\u4EBA\u4ED4\u7EC6\u9605\u8BFB\u8BA2\u9605\u76F8\u5173\u7684 subs \u7684\u586B\u5199\u8BF4\u660E (>\u03C9<)b\n\u3010\u4E3B\u4EBA\u8D26\u53F7\u90E8\u5206\u975E\u5FC5\u586B\u3011\u7136\u540E\u518D\u544A\u8BC9\u5973\u4EC6\u60A8\u7684 \u4E3B\u4EBA\u8D26\u53F7 (///\u25BD///)\uFF0C\u5E76\u9009\u62E9\u60A8\u5E0C\u671B\u5973\u4EC6\u670D\u52A1\u7684\u5E73\u53F0\uFF5E\n\u63A5\u7740\uFF0C\u8BF7\u8BA4\u771F\u586B\u5199 \u4E3B\u4EBA\u7684 ID \u548C \u7FA4\u7EC4 ID\uFF0C\u786E\u4FDD\u4FE1\u606F\u5B8C\u5168\u6B63\u786E\uFF5E\n\u8FD9\u6837\u5973\u4EC6\u624D\u80FD\u987A\u5229\u627E\u5230\u60A8\u5E76\u51C6\u786E\u6C47\u62A5\u52A8\u6001\u5462 (\u2267\u25BD\u2266)\n\n\u4E0D\u7528\u7740\u6025\uFF0C\u5973\u4EC6\u4F1A\u4E00\u76F4\u5728\u8FD9\u91CC\u966A\u7740\u60A8\uFF0C\u4E00\u6B65\u4E00\u6B65\u5B8C\u6210\u8BBE\u7F6E\uFF5E\n\u4E3B\u4EBA\u53EA\u8981\u4E56\u4E56\u586B\u597D\u8FD9\u4E9B\u4FE1\u606F\uFF0C\u5C31\u80FD\u8BA9\u5973\u4EC6\u53D8\u5F97\u8D85\u7EA7\u542C\u8BDD\u3001\u8D85\u7EA7\u52E4\u5FEB\u5566 (>///<)\u2661\n\n\u60F3\u8981\u91CD\u65B0\u767B\u5F55\u7684\u8BDD\uFF0C\u53EA\u9700\u8981\u70B9\u51FB\u4E2A\u4EBA\u540D\u7247\u7684\u201CBilibili\u201DLogo\u54E6\uFF5E\n\n\u4E3B\u4EBA\uFF5E\u6CE8\u610F\u4E8B\u9879\u8981\u4ED4\u7EC6\u770B\u5440 (>_<)\u2661  \n- \u5982\u679C\u4E3B\u4EBA\u4F7F\u7528\u7684\u662F onebot \u673A\u5668\u4EBA\uFF0C\u5E73\u53F0\u540D\u8BF7\u586B\u5199 onebot\uFF0C\u800C\u4E0D\u662F qq \u54E6\uFF5E  \n- \u540C\u6837\u7684\u5440\uFF0C\u5982\u679C\u662F onebot \u673A\u5668\u4EBA\uFF0C\u8BF7\u52A1\u5FC5\u586B\u5199 onebot\uFF0C\u4E0D\u8981\u5199\u6210 qq \u54E6\uFF5E  \n- \u5973\u4EC6\u518D\u63D0\u9192\u4E00\u6B21\uFF5Eonebot \u673A\u5668\u4EBA\u5C31\u586B onebot\uFF0C\u5343\u4E07\u4E0D\u8981\u5199 qq \u54E6\uFF5E  \n\n\u4E56\u4E56\u9075\u5B88\u8FD9\u4E9B\u89C4\u5219\uFF0C\u5973\u4EC6\u624D\u80FD\u987A\u5229\u5E2E\u4E3B\u4EBA\u5DE5\u4F5C\u5462 (*>\u03C9<)b\n\n---\n";
declare module "koishi" {
  interface Events {
    "bilibili-notify/login-status-report"(data: BiliDataServer): void;
    "bilibili-notify/advanced-sub"(subs: Subscriptions): void;
    "bilibili-notify/ready-to-recive"(): void;
  }
}
declare module "@koishijs/plugin-console" {
  namespace Console {
    interface Services {
      "bilibili-notify": BilibiliNotifyDataServer;
    }
  }
  interface Events {
    "bilibili-notify/start-login"(): void;
    "bilibili-notify/restart-plugin"(): void;
    "bilibili-notify/request-cors"(url: string): any;
  }
}
declare function apply(ctx: Context, config: BilibiliNotifyConfig): void;
declare const Config: Schema<BilibiliNotifyConfig>;
//#endregion
export { Config, apply, inject, name, usage };